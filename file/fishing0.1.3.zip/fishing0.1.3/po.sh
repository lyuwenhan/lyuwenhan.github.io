g++ .code/decode.cpp -o .code/decode.run
stty raw -echo
./.code/decode.run
stty cooked echo