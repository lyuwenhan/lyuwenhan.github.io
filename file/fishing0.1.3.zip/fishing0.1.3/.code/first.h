#ifndef first_defined
#define first_defined
#include<hashtable.h>
#include<iostream>
#include<fstream>
#include<string>
using std::cout;
using std::hash;
using std::string;
using std::ostream;
using std::ofstream;
using std::to_string;
#include"variate.h"
#include"function.h"
#include"checkpoint.h"
namespace first{
	inline void fishing(){
		clear();
		print("\033[33;1m1.开始钓鱼\033[m, 2.进入商店, 3.存档, 4.读档, 5.设置自动保存, 6.开发者模式, 7.设置, 8.退出, 其他输入无效。");
		cout << endl << "\033[31;1m按下1\033[m" << endl;
		while(getch() != '1');
		clear();
		print("\033[33;1m1.开始钓鱼\033[m, 2.清理鱼池,  3.全部卖出, 4.全部卖出并退出");
		print("当前污染等级: 0");
		cout << "\033[1;31m腐烂的鱼:\033[m" << endl << "    暂无" << endl << "\033[1;37m普通鱼:\033[m" << endl << "    暂无" << endl << "\033[1;35m紫水晶鱼:\033[m" << endl << "    暂无" << endl << "\033[1;34m青金石鱼:\033[m" << endl << "    暂无" << endl << "\033[1;33m金鱼:\033[m" << endl << "    暂无" << endl << "\033[1;32m绿宝石鱼:\033[m" << endl << "    暂无" << endl << "\033[1;36m钻石鱼:\033[m" << endl << "    暂无" << endl;
		cout << endl << "\033[31;1m按下1\033[m" << endl;
		while(getch() != '1');
		clear();
		printa("欢迎进入钓鱼, 钓鱼可以赚钱, 然后可以升级。");
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << "                               /" << endl << "                              /" << endl << "                             /" << endl << "                            /" << endl << "                         o /" << endl << "                        /|v" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << "                          |" << endl << "                          |" << endl << "                          |" << endl << "                          |" << endl << "                         o|" << endl << "                        /||" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << "                        |" << endl << "                        |" << endl << "                        |" << endl << "                        |" << endl << "                        |o" << endl << "                        ||\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << "                  j\\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << "                  |\\" << endl << "                  j \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  j  \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  j   \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  j    \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  j     V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  j     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~\033[mj\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		int stime = 10;
		sleep(stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl << "" << "O\33[m\033[1;34m~~~~~~~~~~~~~~~~~\033[mj\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		for(int i = 1; i <= 17; i++){
			clear();
			cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl;
			for(int j = 1; j < i; j++){
				cout << "\033[1;34m~\033[m";
			}
			cout << ">" << "O\33[m";
			for(int j = i; j <= 16; j++){
				cout << "\033[1;34m~\033[m";
			}
			cout << "j\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
			sleep(0.5);
		}
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~\033[m>" << "O\33[m\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  " << "O\33[m     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~\033[m^\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  " << "O\33[m     V|\\" << endl << "                  ^     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  " << "O\33[m    \\ o" << endl << "                  ^     V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  " << "O\33[m   \\" << endl << "                  ^    \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  " << "O\33[m  \\" << endl << "                  ^   \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << "                  |\\" << endl << "                  " << "O\33[m \\" << endl << "                  ^  \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << "                  " << "O\33[m\\" << endl << "                  ^ \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << "                       >" << "O\33[m" << endl << "                        |" << endl << "                        |" << endl << "                        |" << endl << "                        |o" << endl << "                        ||\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << "                         >" << "O\33[m" << endl << "                          |" << endl << "                          |" << endl << "                          |" << endl << "                         o|" << endl << "                        /||" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << "                              >" << "O\33[m" << endl << "                              /" << endl << "                             /" << endl << "                            /" << endl << "                         o /" << endl << "                        /|v" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o         v" << endl << "                        /|\\--------" << "O\33[m" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------v" << endl << "                        /_\\___     " << "O\33[m" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___     V " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~\033[m" << "O\33[m\033[1;34m~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___ " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~\\\033[mv\033[1;34m/~~~~~~\033[m|" << endl << "                              |    " << "O\33[m       |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___ " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |    v       |" << endl << "                              |    " << "O\33[m       |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___ " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |    >" << "O\33[m      |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___ " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |     >" << "O\33[m     |" << endl << "                              |____________|" << endl;
		sleep(0.5);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___ " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >" << "O\33[m  x1|" << endl << "                              |____________|" << endl;
		variate::cnt = 1;
		sleep(0.5);
		clear();
		printa((string)"你钓到了一条普通的鱼\033[m, 价值$10");
		clear();
		print("1.开始钓鱼, 2.清理鱼池,  3.全部卖出, \033[33;1m4.全部卖出并退出\033[m");
		print("当前污染等级: 0");
		cout << "\033[1;31m腐烂的鱼:\033[m" << endl << "    暂无" << endl << "\033[1;37m普通鱼:\033[m" << endl << "    \033[1;32m新鲜度:10 价格:10\033[m" << endl << "\033[1;35m紫水晶鱼:\033[m" << endl << "    暂无" << endl << "\033[1;34m青金石鱼:\033[m" << endl << "    暂无" << endl << "\033[1;33m金鱼:\033[m" << endl << "    暂无" << endl << "\033[1;32m绿宝石鱼:\033[m" << endl << "    暂无" << endl << "\033[1;36m钻石鱼:\033[m" << endl << "    暂无" << endl;
		cout << endl << "\033[31;1m按下4\033[m" << endl;
		while(getch() != '4');
		sleep(1);
	}
	inline void shop(){
		clear();
		print("1.开始钓鱼, \033[33;1m2.进入商店\033[m, 3.存档, 4.读档, 5.设置自动保存, 6.开发者模式, 7.设置, 8.退出, 其他输入无效。");
		cout << endl << "\033[31;1m按下2\033[m" << endl;
		while(getch() != '2');
		clear();
		print("\033[33;1m1.普通商店\033[m, 2.超级商店, 3.退出。");
		cout << endl << "\033[31;1m按下1\033[m" << endl;
		while(getch() != '1');
		clear();
		printa("欢迎进入商店, 这里可以买很多有用的东西。");
		clear();
		print("1.升级上钩速度, 2.升级钓鱼收益, 3.脱钩概率, 4.购买清洁剂, 5.升级清洁剂, \033[33;1m6.返回\033[m。");
		print("上钩速度: ");
		print("    当前平均时间: 70, 升级后平均时间: 65");
		print("    升级花费: $5, 当前金币数量: $10");
		print("钓鱼收益: ");
		print("    当前平均收益: 15, 升级后平均收益: 16");
		print("    升级花费: $20, 当前金币数量: $10");
		print("脱钩概率: ");
		print("    当前脱钩概率: 50%, 升级后脱钩概率: 40%");
		print("    升级花费: $100, 当前金币数量: $10");
		print("清洁剂: ");
		print("    当前清洁剂个数: 0");
		print("    购买花费: $10, 当前金币数量: $10");
		print("清洁剂: ");
		print("    当前清洁剂个数: 0");
		print("    购买花费: $10, 当前金币数量: $10");
		print("清洁效率: ");
		print("    当前清洁效率: 一次降低1级, 升级后清洁效率: 一次降低2级");
		print("    购买花费: $30, 当前金币数量: $" + to_string(variate::money));
		cout << endl << "\033[31;1m按下6\033[m" << endl;
		while(getch() != '6');
		sleep(1);
	}
	inline int check(){
		ifstream in(".code/first.txt");
		if(!in.good()){
			return 0;
		}
		string a;
		in >> a;
		return (a == "watched" ? 1 : (a == "skip" ? 2 : 0));
	}
	// inline bool lastif(){
	// 	ifstream in("checkpoint/last");
	// 	return in.good();
	// }
	// inline bool last(){
	// 	ifstream in("checkpoint/last");
	// 	if(!in.good()){
	// 		return false;
	// 	}
	// 	string a;
	// 	in >> a;
	// 	return checkpoint::decode(a, false);
	// }
	inline void first(){
		int old = variate::spead;
		variate::spead = 2;
		// bool laif = lastif();
		// print((string)"检测到" + (laif ? (string)"" : (string)"没") + (string)"有已保存的last, 按1读档, " + (laif ? (string)"按2读last, " : (string)"") + (string)"按s跳过");
		// {
		// 	char c = getch();
		// 	while(c != '1' && c != '2' && c != 's'){
		// 		c = getch();
		// 	}
		// 	if(c == '1'){
		// 		clear();
		// 		checkpoint::read();
		// 		return true;
		// 	}else if(c == '2'){
		// 		clear();
		// 		last();
		// 		return true;
		// 	}
		// }
		clear();
		int chk = check();
		print((string)"检测到" + (chk == 0 ? (string)"未观看" : (chk == 1 ? (string)"已观看" : (string)"已跳")) + (string)"过新手教程" + (chk == 2 ? ", 是否重新观看" : "") + ", 按s跳过, 按enter观看");
		{
			char c;
			while(c != 's' && c != '\r'){
				c = getch();
			}
			if(c == 's'){
				clear();
				if(!chk){
					{
						ofstream out(".code/first.txt");
						out << "skip" << std::endl;
						sleep(1);
					}
				}
				return;
			}
		}
		{
			ofstream out(".code/first.txt");
			out << "watched" << std::endl;
			sleep(1);
		}
		fishing();
		shop();
		variate::spead = old;
		clear();
	}
}
#endif
