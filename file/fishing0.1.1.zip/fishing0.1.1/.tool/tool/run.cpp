#include<iostream>
using namespace std;
struct endline{}eline;
inline ostream& operator<<(ostream& out, endline){
	out.flush();
	out << '\r' << std::endl;
	return out;
}
int main(){
cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "~~~~~~~~~~~~~~~~~~~~~~~|      |~~~~~~~~~~~~|" << endl << "                 O<           |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
}
