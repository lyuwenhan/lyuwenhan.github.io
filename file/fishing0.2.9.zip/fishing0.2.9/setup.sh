#!/bin/bash
stty -echo raw
clear
echo -e "loading...\r"
clear
chmod u+x .run/*.sh > /dev/null 2>&1 && chmod u+x .run/*.run > /dev/null 2>&1 && chmod u+x .code/*.sh > /dev/null 2>&1 && chmod u+x .code/*.run > /dev/null 2>&1 && chmod u+x setup.sh > /dev/null 2>&1
./.run/setup.run 2>/dev/null
if ! [ $? -eq 0 ];then
    clear
    stty echo cooked
    echo "运行错误"
    exit 1
fi
clear
stty echo cooked