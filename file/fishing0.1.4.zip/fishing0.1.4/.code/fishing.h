#ifndef fishing_defined
#define fishing_defined
#include<hashtable.h>
#include<iostream>
#include<iomanip>
#include<vector>
using std::to_string;
using std::ostream;
using std::string;
using std::vector;
using std::hash;
using std::pair;
using std::cout;
using std::setw;
using std::max;
#include"error.h"
#include"variate.h"
#include"function.h"
namespace fishing{
/*
\033[1;31m腐烂的 * 0   1%
\033[1;37m普通   * 1   80%
\033[1;35m紫水晶 * 2   14%
\033[1;34m青金石 * 5   4%
\033[1;33m金     * 10  0.9%
\033[1;32m绿宝石 * 50  0.09%
\033[1;36m钻石   * 100 0.01%
*/
	char paint[11][45] = {
	"                                            ",
	"                                            ",
	"                                            ",
	"                                            ",
	"                         o                  ",
	"                        /|\\--------         ",
	"                        /_\\___              ",
	"~~~~~~~~~~~~~~~~~~~~~~~|      |~~~~~~~~~~~~|",
	"                              |            |",
	"                              |            |",
	"                              |____________|"};
	string color[11][45];
	vector<int> fish_time[7];
	vector<int> fish_money[7];
	int dirty = 0;
	const string fish_name[7] = {"腐烂的", "普通的", "紫水晶", "青金石", "金", "绿宝石", "钻石"};
	const string fish_color[7] = {"\033[1;31m", "\033[1;37m", "\033[1;35m", "\033[1;34m", "\033[1;33m", "\033[1;32m", "\033[1;36m"};
	const int fish_add[7] = {0, 1, 2, 5, 10, 50, 100};
	const int fish_gai[7] = {100, 8000, 1400, 400, 90, 9, 1};
	inline int rand_time(int l = variate::level){
		return random(variate::mintime[l], variate::maxtime[l]);
	}
	inline int gr(int l = variate::get_level){
		return random(variate::minget[l], variate::maxget[l]);
	}
	inline int gettype(){
		int ty = random(1, 10000);
		for(int i = 0; i <= 6; i++){
			ty -= fish_gai[i];
			if(ty <= 0){
				return i;
			}
		}
		return 0;
	}
	inline void get(bool is_big, int type){
		clear();
		int pri = gr() * (is_big + 1) * fish_add[type];
		printa((string)"你钓到了一条" + fish_color[type] + fish_name[type] + (is_big ? "大" : "") + "鱼\033[m, 价值$" + to_string(pri));
		fish_time[type].push_back(10);
		fish_money[type].push_back(pri);
		variate::cnt++;
	}
	inline void draw(){
		clear();
		for(int i = 0; i < 11; i++){
			for(int j = 0; j < 45; j++){
				cout << "\033[m" << color[i][j] << paint[i][j] << "\033[m";
			}
			cout << endl;
		}
		cout << "累计钓鱼数量: " << variate::cnt << endl;
	}
	inline void fishing(bool is_big, int type){
		color[7][18] = "\033[1;34m";
		paint[7][18] = '~';
		color[6][19] = fish_color[type];
		paint[7][19] = '^';
		paint[6][19] = 'O';
		draw();
		sleep(0.5 * (is_big + 1) / variate::stime);
		color[7][19] = "\033[1;34m";
		paint[7][19] = '~';
		color[5][19] = fish_color[type];
		paint[6][19] = '^';
		paint[5][19] = 'O';
		draw();
		sleep(0.5 * (is_big + 1) / variate::stime);
		for(int i = 4; i >= 1; i--){
			color[i + 2][19] = "";
			paint[i + 2][19] = ' ';
			color[i][19] = fish_color[type];
			paint[i + 1][19] = '^';
			paint[i][19] = 'O';
			draw();
			sleep(0.5 * (is_big + 1) / variate::stime);
		}
		paint[5][24] = paint[4][24] = paint[3][24] = paint[2][24] = '|';
		paint[4][23] = paint[3][22] = paint[2][21] = paint[1][20] = paint[1][19] = paint[2][19] = ' ';
		color[1][19] = color[2][19] = "";
		paint[1][23] = '>';
		paint[1][24] = 'O';
		color[1][23] = color[1][24] = fish_color[type];
		draw();
		sleep(0.5 * (is_big + 1) / variate::stime);
		paint[5][26] = 'V';
		paint[4][24] = paint[3][24] = paint[2][24] = paint[1][23] = paint[1][24] = ' ';
		color[1][23] = color[1][24] = "";
		paint[5][26] = paint[4][26] = paint[3][26] = paint[2][26] = '|';
		paint[5][24] = '/';
		paint[1][25] = '>';
		paint[1][26] = 'O';
		color[1][25] = color[1][26] = fish_color[type];
		draw();
		sleep(0.5 * (is_big + 1) / variate::stime);
		paint[5][26] = paint[4][27] = paint[3][28] = paint[2][29] = '/';
		color[1][25] = color[1][26] = "";
		paint[4][26] = paint[3][26] = paint[2][26] = paint[1][25] = paint[1][26] = ' ';
		paint[1][29] = '>';
		paint[1][30] = 'O';
		color[1][29] = color[1][30] = fish_color[type];
		draw();
		sleep(0.5 * (is_big + 1) / variate::stime);
		paint[4][27] = paint[3][28] = paint[2][29] = paint[1][29] = paint[1][30] = ' ';
		paint[5][26] = '\\';
		paint[5][27] = paint[5][28] = paint[5][29] = paint[5][30] = paint[5][31] = paint[5][32] = paint[5][33] = paint[5][34] = '-';
		paint[4][35] = 'V';
		paint[5][35] = 'O';
		color[5][35] = color[4][35] = fish_color[type];
		color[1][29] = color[1][30] = "";
		draw();
		sleep(0.5 * (is_big + 1) / variate::stime);
		paint[6][35] = 'O';
		paint[4][35] = ' ';
		paint[5][35] = 'V';
		color[6][35] = fish_color[type];
		color[4][35] = "";
		draw();
		sleep(0.5 * (is_big + 1) / variate::stime);
		paint[7][34] = '\\';
		paint[7][36] = '/';
		for(int i = 7; i <= 8; i++){
			paint[i][35] = 'O';
			paint[i - 2][35] = ' ';
			paint[i - 1][35] = 'V';
			color[i][35] = fish_color[type];
			color[i - 2][35] = "";
			draw();
			sleep(0.5 * (is_big + 1) / variate::stime);
		}
		paint[7][34] = paint[7][36] = '~';
		paint[9][35] = 'O';
		paint[7][35] = '~';
		paint[8][35] = 'V';
		color[9][35] = fish_color[type];
		color[7][35] = "\033[1;34m";
		draw();
		sleep(0.5 * (is_big + 1) / variate::stime);//38
		paint[9][36] = 'O';
		paint[8][35] = ' ';
		paint[9][35] = '>';
		color[9][36] = fish_color[type];
		color[8][35] = "";
		draw();
		sleep(0.5 * (is_big + 1) / variate::stime);//38
		for(int i = 37; i <= 38; i++){
			paint[9][i] = 'O';
			paint[9][i - 2] = ' ';
			paint[9][i - 1] = '>';
			color[9][i] = fish_color[type];
			color[9][i - 2] = "";
			draw();
			sleep(0.5 * (is_big + 1) / variate::stime);
		}
		paint[9][38] = paint[9][37] = ' ';
		color[9][38] = color[9][37] = "";
		get(is_big, type);
	}
	inline void fishingslip(bool is_big, int type){
		color[7][18] = "\033[1;34m";
		paint[7][18] = '~';
		color[6][19] = fish_color[type];
		paint[7][19] = '^';
		paint[6][19] = 'O';
		draw();
		sleep(0.3 * (is_big + 1) / variate::stime);
		color[7][19] = "\033[1;34m";
		paint[7][19] = '~';
		color[6][19] = "";
		paint[6][19] = ' ';
		paint[6][20] = '^';
		paint[5][19] = 'O';
		color[6][20] = color[5][19] = fish_color[type];
		draw();
		sleep(0.3 * (is_big + 1) / variate::stime);
		paint[6][20] = paint[5][19] = ' ';
		color[6][20] = color[5][19] = "";
		paint[5][18] = '^';
		paint[4][19] = 'O';
		color[5][18] = color[4][19] = fish_color[type];
		draw();
		sleep(0.3 * (is_big + 1) / variate::stime);
		paint[5][18] = paint[4][19] = ' ';
		color[5][18] = color[4][19] = "";
		paint[4][20] = '^';
		paint[3][19] = 'O';
		color[4][20] = color[3][19] = fish_color[type];
		draw();
		sleep(0.3 * (is_big + 1) / variate::stime);
		paint[2][19] = 'j';
		color[4][20] = "";
		paint[4][20] = ' ';
		color[3][20] = fish_color[type];
		paint[3][20] = '<';
		draw();
		sleep(0.3 * (is_big + 1) / variate::stime);
		color[3][20] = "";
		paint[1][19] = 'j';
		paint[3][20] = paint[2][19] = ' ';
		color[4][19] = fish_color[type];
		paint[3][19] = 'V';
		paint[4][19] = 'O';
		draw();
		sleep(0.5 * (is_big + 1) / variate::stime);
		color[3][19] = "";
		color[5][19] = fish_color[type];
		paint[3][19] = ' ';
		paint[4][19] = 'V';
		paint[5][19] = 'O';
		draw();
		sleep(0.5 * (is_big + 1) / variate::stime);
		color[4][19] = "";
		color[6][19] = fish_color[type];
		paint[4][19] = ' ';
		paint[5][19] = 'V';
		paint[6][19] = 'O';
		draw();
		sleep(0.5 * (is_big + 1) / variate::stime);
		paint[7][18] = '\\';
		paint[7][20] = '/';
		for(int i = 7; i <= 8; i++){
			color[i - 2][19] = "";
			color[i][19] = fish_color[type];
			paint[i - 2][19] = ' ';
			paint[i - 1][19] = 'V';
			paint[i][19] = 'O';
			draw();
			sleep(0.5 / (is_big + 1) / variate::stime);
		}
		paint[7][18] = paint[7][20] = paint[7][19] = '~';
		color[7][19] = "\033[1;34m";
		color[9][19] = fish_color[type];
		paint[8][19] = 'V';
		paint[9][19] = 'O';
		draw();
		sleep(0.5 / (is_big + 1) / variate::stime);
		paint[8][19] = ' ';
		color[8][19] = "";
		color[10][19] = fish_color[type];
		paint[9][19] = 'V';
		paint[10][19] = 'O';
		draw();
		sleep(0.5 / (is_big + 1) / variate::stime);
		paint[9][19] = ' ';
		color[9][19] = "";
		paint[10][19] = 'V';
		draw();
		sleep(0.5 / (is_big + 1) / variate::stime);
		paint[10][19] = ' ';
		color[10][19] = "";
		draw();
		sleep(0.5 / (is_big + 1) / variate::stime);
		paint[4][23] = paint[3][22] = paint[2][21] = paint[1][20] = paint[1][19] = ' ';
		paint[5][24] = '/';
	}
	inline void front_fishing(bool is_big, int type, int slip){
		for(int i = 0; i < 11; i++){
			for(int j = 0; j < 45; j++){
				color[i][j] = "";
			}
		}
		for(int i = 0; i <= 22; i++){
			color[7][i] = "\033[1;34m";
		}
		for(int i = 31; i <= 42; i++){
			color[7][i] = "\033[1;34m";
		}
		draw();
		sleep(0.5 / variate::stime);
		for(int i = 27; i <= 34; i++){
			paint[5][i] = ' ';
		}
		paint[5][26] = 'V';
		paint[4][27] = paint[3][28] = paint[2][29] = paint[1][30] = '/';
		draw();
		sleep(0.5 / variate::stime);
		paint[4][27] = paint[3][28] = paint[2][29] = paint[1][30] = ' ';
		paint[5][26] = paint[4][26] = paint[3][26] = paint[2][26] = paint[1][26] = '|';
		draw();
		sleep(0.5 / variate::stime);
		paint[5][26] = '\\';
		paint[4][26] = paint[3][26] = paint[2][26] = paint[1][26] = ' ';
		paint[5][24] = paint[4][24] = paint[3][24] = paint[2][24] = paint[1][24] = '|';
		draw();
		sleep(0.5 / variate::stime);
		paint[4][24] = paint[3][24] = paint[2][24] = paint[1][24] = ' ';
		paint[5][24] = 'V';
		paint[4][23] = paint[3][22] = paint[2][21] = paint[1][20] = '\\';
		draw();
		sleep(0.5 / variate::stime);
		paint[1][19] = 'j';
		draw();
		sleep(0.5 / variate::stime);
		for(int i = 2; i <= 6; i++){
			paint[i - 1][19] = '|';
			paint[i][19] = 'j';
			draw();
			sleep(0.5 / variate::stime);
		}
		paint[6][19] = '|';
		paint[7][19] = 'j';
		color[7][19] = "";
		draw();
		int stime = rand_time();
		sleep(stime);
		color[7][0] = fish_color[type];
		paint[7][0] = 'O';
		draw();
		sleep(0.5 * (is_big + 1) / variate::stime);
		color[7][1] = fish_color[type];
		paint[7][0] = '>';
		paint[7][1] = 'O';
		draw();
		sleep(0.5 * (is_big + 1) / variate::stime);
		for(int i = 2; i <= 19; i++){
			color[7][i - 2] = "\033[1;34m";
			paint[7][i - 2] = '~';
			color[7][i] = fish_color[type];
			paint[7][i - 1] = '>';
			paint[7][i] = 'O';
			draw();
			sleep(0.5 * (is_big + 1) / variate::stime);
		}
		if(slip){
			fishingslip(is_big, type);
		}else{
			fishing(is_big, type);
		}
	}
	inline void fishing_choose(){
		bool b = (random(1, 100) <= variate::bf);
		bool s = (random(1, 100) <= variate::slip);
		int type = gettype();
		front_fishing(b, type, s);
	}
	inline double fresh(int a){
		if(a >= 8){
			return 1.2;
		}else if(a <= 2){
			return 0.8;
		}else{
			return 1;
		}
	}
	inline void fishing_setup(){
		while(true){
			clear();
			print("1.开始钓鱼, 2.清理鱼池,  3.全部卖出, 4.全部卖出并退出");
			print("当前污染等级: " + to_string(dirty));
			for(int i = 0; i <= 6; i++){
				cout << fish_color[i] << fish_name[i] + "鱼:" << endl;
				for(int j = 0; j < fish_time[i].size(); j++){
					if(fish_time[i][j] >= 8){
						cout << "\033[1;32m";
					}else if(fish_time[i][j] <= 2){
						cout << "\033[1;31m";
					}else{
						cout << "\033[1m";
					}
					cout << "    新鲜度:" << fish_time[i][j] << " 价格:" << int(fish_money[i][j] * (1 - 0.02 * dirty) * fresh(fish_time[i][j])) << "\033[m" << endl;
				}
				if(fish_time[i].empty()){
					cout << "    暂无\033[m" << endl;
				}
			}
			while(true){
				char c = getch();
				if(c == '1'){
					for(int i = 0; i <= 6; i++){
						for(int j = 0; j < fish_time[i].size(); j++){
							fish_time[i][j] -= dirty + 1;
							if(fish_time[i][j] <= 0){
								if(i == 0){
									dirty++;
								}else{
									fish_time[i - 1].push_back(10);
									fish_money[i - 1].push_back(max(fish_money[i][j] - 10, 0));
								}
								for(int k = j + 1; k < fish_time[i].size(); k++){
									fish_time[i][k - 1] = fish_time[i][k];
									fish_money[i][k - 1] = fish_money[i][k];
								}
								fish_time[i].pop_back();
								fish_money[i].pop_back();
								j--;
							}
						}
					}
					fishing_choose();
					break;
				}else if(c == '2'){
					clear();
					if(!dirty){
						cout << "无需清理" << endl;
						break;
					}
					while(true){
						if(variate::cleaning_ball){
							print("1.清理, 2.退出");
							print("当前污染等级: " + to_string(variate::cleaning_ball));
							print("当前清洁剂个数: " + to_string(variate::cleaning_ball));
							char c = 0;
							while(true){
								c = getch();
								if(c == '1' || c == '2'){
									break;
								}
							}
							if(c == '1'){
								variate::cleaning_ball--;
								dirty--;
							}else{
								break;
							}
						}else{
							print("1.购买清洁剂并清理, 2.退出");
							print("当前污染等级: " + to_string(variate::cleaning_ball));
							print("清洁剂: ");
							print("    购买花费: $20, 当前金币数量: $" + to_string(variate::money));
							char c = 0;
							while(true){
								c = getch();
								if(c == '1' || c == '2'){
									break;
								}
							}
							if(c == '1'){
								if(variate::money < 20){
									cout << "金钱不够" << endl;
									break;
								}else{
									variate::money -= 20;
									dirty--;
								}
							}else{
								break;
							}
						}
						if(!dirty){
							cout << "清理完成" << endl;
							break;
						}
					}
					break;
				}else if(c == '3'){
					error("sale");
					for(int i = 0; i <= 6; i++){
						for(int j = 0; j < fish_time[i].size(); j++){
							variate::money += (int)(fish_money[i][j] * (1 - 0.02 * dirty) * fresh(fish_time[i][j]));
						}
						while(!fish_time[i].empty()){
							fish_time[i].pop_back();
						}
						while(!fish_money[i].empty()){
							fish_money[i].pop_back();
						}
					}
					clear();
					cout << "售卖中" << endl;
					break;
				}else if(c == '4'){
					for(int i = 0; i <= 6; i++){
						for(int j = 0; j < fish_time[i].size(); j++){
							variate::money += (int)(fish_money[i][j] * (1 - 0.02 * dirty) * fresh(fish_time[i][j]));
						}
						while(!fish_time[i].empty()){
							fish_time[i].pop_back();
						}
						while(!fish_money[i].empty()){
							fish_money[i].pop_back();
						}
					}
					return;
				}
			}
			sleep(1);
		}
	}
}
#endif
