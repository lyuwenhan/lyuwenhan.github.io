#ifndef fishing_defined
#define fishing_defined
#include<hashtable.h>
#include<iostream>
#include<iomanip>
#include<vector>
using std::to_string;
using std::ostream;
using std::string;
using std::vector;
using std::hash;
using std::pair;
using std::cout;
using std::setw;
using std::max;
#include"error.h"
#include"variate.h"
#include"function.h"
namespace fishing{
/*
\033[1;31m腐烂的 * 0   1%
\033[1;37m普通   * 1   80%
\033[1;35m紫水晶 * 2   14%
\033[1;34m青金石 * 5   4%
\033[1;33m金     * 10  0.9%
\033[1;32m绿宝石 * 50  0.09%
\033[1;36m钻石   * 100 0.01%
*/
	vector<int> fish_time[7];
	vector<int> fish_money[7];
	int dirty = 0;
	const string fish_name[7] = {"腐烂的", "普通的", "紫水晶", "青金石", "金", "绿宝石", "钻石"};
	const string fish_color[7] = {"\033[1;31m", "\033[1;37m", "\033[1;35m", "\033[1;34m", "\033[1;33m", "\033[1;32m", "\033[1;36m"};
	const int fish_add[7] = {0, 1, 2, 5, 10, 50, 100};
	const int fish_gai[7] = {100, 8000, 1400, 400, 90, 9, 1};
	string last = "\033[1;37m";
	inline int level_rand(int l = variate::level){
		return random(variate::mintime[l], variate::maxtime[l]);
	}
	inline int gr(int l = variate::get_level){
		return random(variate::minget[l], variate::maxget[l]);
	}
	inline int gbr(int l = variate::get_level){
		return random(variate::minget[l] * 2, variate::maxget[l] * 2);
	}
	inline int get_rand(bool is_big){
		return (is_big ? gbr() : gr());
	}
	inline int getgiant_rand(){
		return random(9000, 10000);
	}
	inline int gettype(){
		int ty = random(1, 10000);
		for(int i = 0; i <= 6; i++){
			ty -= fish_gai[i];
			if(ty <= 0){
				return i;
			}
		}
	}
	inline void get(bool is_big, int type){
		int pri = get_rand(is_big) * fish_add[type];
		printa((string)"你钓到了一条" + fish_color[type] + fish_name[type] + (is_big ? "大" : "") + "鱼\033[m, 价值$" + to_string(pri));
		if(type){
			fish_time[type].push_back(10);
			fish_money[type].push_back(pri);
		}else{
			fish_time[type].push_back(5);
			fish_money[type].push_back(0);
		}
	}
	inline void getgiant(){
		int pri = getgiant_rand();
		variate::money += pri;
		printa((string)"你钓到了一条巨型鲨鱼, 价值$" + to_string(pri));
	}
	inline void fishing0(bool is_big, int type){
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << endl << "                               /" << endl << "                              /" << endl << "                             /" << endl << "                            /" << endl << "                         o /" << endl << "                        /|v" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << endl << "                          |" << endl << "                          |" << endl << "                          |" << endl << "                          |" << endl << "                         o|" << endl << "                        /||" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << endl << "                        |" << endl << "                        |" << endl << "                        |" << endl << "                        |" << endl << "                        |o" << endl << "                        ||\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << endl << "                  j\\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  j \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  j  \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  j   \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  j    \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  j     V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  j     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~\033[mj\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		int stime = level_rand();
		sleep(stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl << fish_color[type] << "O\33[m\033[1;34m~~~~~~~~~~~~~~~~~\033[mj\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		for(int i = 1; i <= 17; i++){
			clear();
			cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl;
			for(int j = 1; j < i; j++){
				cout << "\033[1;34m~\033[m";
			}
			cout << fish_color[type] << ">O\33[m";
			for(int j = i; j <= 16; j++){
				cout << "\033[1;34m~\033[m";
			}
			cout << "j\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
			sleep(0.5 * (is_big + 1) / variate::stime);
		}
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~\033[m" << fish_color[type] << ">O\33[m\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  " << fish_color[type] << "O\33[m     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~\033[m" << fish_color[type] << "^\033[m\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  " << fish_color[type] << "O\33[m     V|\\" << endl << "                  " << fish_color[type] << "^\033[m     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  " << fish_color[type] << "O\33[m    \\ o" << endl << "                  " << fish_color[type] << "^\033[m     V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  " << fish_color[type] << "O\33[m   \\" << endl << "                  " << fish_color[type] << "^\033[m    \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  " << fish_color[type] << "O\33[m  \\" << endl << "                  " << fish_color[type] << "^\033[m   \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  " << fish_color[type] << "O\33[m \\" << endl << "                  " << fish_color[type] << "^\033[m  \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  " << fish_color[type] << "O\33[m\\" << endl << "                  " << fish_color[type] << "^\033[m \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                       " << fish_color[type] << ">O\33[m" << endl << "                        |" << endl << "                        |" << endl << "                        |" << endl << "                        |o" << endl << "                        ||\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                         " << fish_color[type] << ">O\33[m" << endl << "                          |" << endl << "                          |" << endl << "                          |" << endl << "                         o|" << endl << "                        /||" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                              " << fish_color[type] << ">O\33[m" << endl << "                              /" << endl << "                             /" << endl << "                            /" << endl << "                         o /" << endl << "                        /|v" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o         " << fish_color[type] << "v\033[m" << endl << "                        /|\\--------" << fish_color[type] << "O\33[m" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << fish_color[type] << "v\033[m" << endl << "                        /_\\___     " << fish_color[type] << "O\33[m" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___     " << fish_color[type] << "v\033[m " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~\033[m" << fish_color[type] << "O\33[m\033[1;34m~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___ " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~\\\033[m" << fish_color[type] << "v\033[m\033[1;34m/~~~~~~\033[m|" << endl << "                              |    " << fish_color[type] << "O\33[m       |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___ " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |    " << fish_color[type] << "v\033[m       |" << endl << "                              |    " << fish_color[type] << "O\033[m       |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___ " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |    " << fish_color[type] << ">O\33[m      |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___ " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |     " << fish_color[type] << ">O\33[m     |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___ " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << fish_color[type] << ">O\33[m  x1|" << endl << "                              |____________|" << endl;
		variate::cnt = 1;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		last = fish_color[type];
		get(is_big, type);
	}
	inline void fishing1(bool is_big, int type){
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << endl << "                               /" << endl << "                              /" << endl << "                             /" << endl << "                            /" << endl << "                         o /" << endl << "                        /|v" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << endl << "                          |" << endl << "                          |" << endl << "                          |" << endl << "                          |" << endl << "                         o|" << endl << "                        /||" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << endl << "                        |" << endl << "                        |" << endl << "                        |" << endl << "                        |" << endl << "                        |o" << endl << "                        ||\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << endl << "                  j\\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  j \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  j  \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  j   \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  j    \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  j     V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  j     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~\033[mj\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		int stime = level_rand();
		sleep(stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl << fish_color[type] << "O\33[m\033[1;34m~~~~~~~~~~~~~~~~~\033[mj\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		for(int i = 1; i <= 17; i++){
			clear();
			cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl;
			for(int j = 1; j < i; j++){
				cout << "\033[1;34m~\033[m";
			}
			cout << fish_color[type] << ">O\33[m";
			for(int j = i; j <= 16; j++){
				cout << "\033[1;34m~\033[m";
			}
			cout << "j\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
			sleep(0.5 * (is_big + 1) / variate::stime);
		}
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~\033[m" << fish_color[type] << ">O\33[m\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  " << fish_color[type] << "O\33[m     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~\033[m" << fish_color[type] << "^\033[m\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  " << fish_color[type] << "O\33[m     V|\\" << endl << "                  " << fish_color[type] << "^\033[m     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  " << fish_color[type] << "O\33[m    \\ o" << endl << "                  " << fish_color[type] << "^\033[m     V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  " << fish_color[type] << "O\33[m   \\" << endl << "                  " << fish_color[type] << "^\033[m    \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  " << fish_color[type] << "O\33[m  \\" << endl << "                  " << fish_color[type] << "^\033[m   \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  " << fish_color[type] << "O\33[m \\" << endl << "                  " << fish_color[type] << "^\033[m  \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  " << fish_color[type] << "O\33[m\\" << endl << "                  " << fish_color[type] << "^\033[m \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                       " << fish_color[type] << ">O\33[m" << endl << "                        |" << endl << "                        |" << endl << "                        |" << endl << "                        |o" << endl << "                        ||\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                         " << fish_color[type] << ">O\33[m" << endl << "                          |" << endl << "                          |" << endl << "                          |" << endl << "                         o|" << endl << "                        /||" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                              " << fish_color[type] << ">O\33[m" << endl << "                              /" << endl << "                             /" << endl << "                            /" << endl << "                         o /" << endl << "                        /|v" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o         " << fish_color[type] << "v\033[m" << endl << "                        /|\\--------" << fish_color[type] << "O\33[m" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << fish_color[type] << "v\033[m" << endl << "                        /_\\___     " << fish_color[type] << "O\33[m" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___     " << fish_color[type] << "v\033[m " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~\033[m" << fish_color[type] << "O\33[m\033[1;34m~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___ " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~\\\033[m" << fish_color[type] << "v\033[m\033[1;34m/~~~~~~\033[m|" << endl << "                              |    " << fish_color[type] << "O\33[m       |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___ " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |    " << fish_color[type] << "v\033[m       |" << endl << "                              |    " << fish_color[type] << "O\33[m " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___ " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |    " << fish_color[type] << ">O\33[m" << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___ " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |     " << fish_color[type] << ">O\33[m" << last << "O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___ " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << fish_color[type] << ">O\033[m" << setw(4) << ("x" + to_string(++variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		last = fish_color[type];
		get(is_big, type);
	}
	inline void fishing1die(bool is_big, int type){
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                               /" << endl << "                              /" << endl << "                             /" << endl << "                            /" << endl << "                         o /" << endl << "                        /|v" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                          |" << endl << "                          |" << endl << "                          |" << endl << "                          |" << endl << "                         o|" << endl << "                        /||" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                        |" << endl << "                        |" << endl << "                        |" << endl << "                        |" << endl << "                        |o" << endl << "                        ||\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  j\\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  j \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  j  \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  j   \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  j    \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  j     V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  j     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~\033[mj\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		int stime = level_rand();
		sleep(stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl << fish_color[type] << "O\33[m\033[1;34m~~~~~~~~~~~~~~~~~\033[mj\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		for(int i = 1; i <= 17; i++){
			clear();
			cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl;
			for(int j = 1; j < i; j++){
				cout << "\033[1;34m~\033[m";
			}
			cout << fish_color[type] << ">O\33[m";
			for(int j = i; j <= 16; j++){
				cout << "\033[1;34m~\033[m";
			}
			cout << "j\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
			sleep(0.5 * (is_big + 1) / variate::stime);
		}
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~\033[m" << fish_color[type] << ">O\33[m\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  " << fish_color[type] << "O\33[m     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~\033[m" << fish_color[type] << "^\033[m\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  " << fish_color[type] << "O\33[m     V|\\" << endl << "                 " << fish_color[type] << "^\033[m      /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  " << fish_color[type] << "O\33[m    \\ o" << endl << "                   " << fish_color[type] << "^\033[m    V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  " << fish_color[type] << "O\33[m   \\" << endl << "                 " << fish_color[type] << "^\033[m     \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  " << fish_color[type] << "O\33[m  \\" << endl << "                   " << fish_color[type] << "^\033[m  \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  " << fish_color[type] << "O\33[m \\" << endl << "                 " << fish_color[type] << "^\033[m   \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                    \\" << endl << "                 " << fish_color[type] << ">O\33[m  \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                  " << fish_color[type] << "v\033[m  \\" << endl << "                  " << fish_color[type] << "O\33[m   \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                  " << fish_color[type] << "v\033[m   \\" << endl << "                  " << fish_color[type] << "O\33[m    \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                  " << fish_color[type] << "v\033[m    \\ o" << endl << "                  " << fish_color[type] << "O\33[m     V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                  " << fish_color[type] << "v\033[m     V|\\" << endl << "                  " << fish_color[type] << "O\33[m     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                  " << fish_color[type] << "v\033[m     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~\\\033[m" << fish_color[type] << "O\33[m\033[1;34m/~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~\\\033[m" << fish_color[type] << "v\033[m\033[1;34m/~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                  " << fish_color[type] << "O\33[m           |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                 " << fish_color[type] << "O<\33[m           |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                 " << fish_color[type] << "v\033[m            |            |" << endl << "                 " << fish_color[type] << "O\33[m            |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                 " << fish_color[type] << "v\033[m            |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                 " << fish_color[type] << "O\33[m            |____________|" << endl;
		sleep(0.3 / (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                 " << fish_color[type] << "v\033[m            |____________|" << endl;
		sleep(0.3 / (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
	}
	inline void fishing2(){
		clear();
		printa("巨型鲨鱼即将出现");
		clear();
		cout << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~\033[mj\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(random(2,5));
		clear();
		cout << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl << "\\\033[1;34m~~~~~~~~~~~~~~~~~\033[mj\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                  |\\                _" << endl << "                  | \\              | |" << endl << "                  |  \\             | |" << endl << "                  |   \\            |_|" << endl << "                  |    \\ o          _" << endl << "                  |     V|\\        (_)" << endl << "\\                 |     /_\\___" << endl << " \\\033[1;34m~~~~~~~~~~~~~~~~\033[mj\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                  |\\                _" << endl << "                  | \\              | |" << endl << "                  |  \\             | |" << endl << "                  |   \\            |_|" << endl << "                  |    \\ o          _" << endl << "\\                 j     V|\\        (_)" << endl << " \\                      /_\\___" << endl << "  \\\033[1;34m~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                  |\\                _" << endl << "                  | \\              | |" << endl << "                  |  \\             | |" << endl << "                  j   \\            |_|" << endl << "                       \\ o          _" << endl << " |\\                     V|\\        (_)" << endl << " | \\                    /_\\___" << endl << "\033[1;34m~\033[m|  \\\033[1;34m~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                  |\\                _" << endl << "                  j \\              | |" << endl << "                     \\             | |" << endl << "                      \\            |_|" << endl << "                       \\ o          _" << endl << "  |\\                    V|\\        (_)" << endl << "  | \\                   /_\\___" << endl << "\033[1;34m~~\033[m|  \\\033[1;34m~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                   \\                _" << endl << "                    \\              | |" << endl << "                     \\             | |" << endl << "                      \\            |_|" << endl << "                       \\ o          _" << endl << "   |\\                   V|\\        (_)" << endl << "   | \\                  /_\\___" << endl << "\033[1;34m~~~\033[m|  \\\033[1;34m~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                        |           _" << endl << "                        |          | |" << endl << "                        |          | |" << endl << "                        |          |_|" << endl << "                        |o          _" << endl << "    |\\                  ||\\        (_)" << endl << "    | \\                 /_\\___" << endl << "\033[1;34m~~~~\033[m|  \\\033[1;34m~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                          |         _" << endl << "                          |        | |" << endl << "                          |        | |" << endl << "                          |        |_|" << endl << "                         o|         _" << endl << "     |\\                 /||        (_)" << endl << "     | \\                /_\\___" << endl << "\033[1;34m~~~~~\033[m|  \\\033[1;34m~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                          |         _" << endl << "                          |        | |" << endl << "                          |        | |" << endl << "                          |        |_|" << endl << "                         o|         _" << endl << "      |\\                /||        (_)" << endl << "      | \\               /_\\___" << endl << "\033[1;34m~~~~~~\033[m|  \\\033[1;34m~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                          |         _" << endl << "                          |        | |" << endl << "                          |        | |" << endl << "                          |        |_|" << endl << "                         o|         _" << endl << "       |\\               /||        (_)" << endl << "       | \\              /_\\___" << endl << "\033[1;34m~~~~~~~\033[m|  \\\033[1;34m~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                          |         _" << endl << "                          |        | |" << endl << "                          |        | |" << endl << "                          |        |_|" << endl << "                         o|         _" << endl << "        |\\              /||        (_)" << endl << "        | \\             /_\\___" << endl << "\033[1;34m~~~~~~~~\033[m|  \\\033[1;34m~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                          |         _" << endl << "                          |        | |" << endl << "                          |        | |" << endl << "                          |        |_|" << endl << "                         o|         _" << endl << "         |\\             /||        (_)" << endl << "         | \\            /_\\___" << endl << "\033[1;34m~~~~~~~~~\033[m|  \\\033[1;34m~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                          |         _" << endl << "                          |        | |" << endl << "                          |        | |" << endl << "                          |        |_|" << endl << "                         o|         _" << endl << "          |\\            /||        (_)" << endl << "          | \\           /_\\___" << endl << "\033[1;34m~~~~~~~~~~\033[m|  \\\033[1;34m~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                          |         _" << endl << "                          |        | |" << endl << "                          |        | |" << endl << "                          |        |_|" << endl << "                         o|         _" << endl << "           |\\           /||        (_)" << endl << "           | \\          /_\\___" << endl << "\033[1;34m~~~~~~~~~~~\033[m|  \\\033[1;34m~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                          |         _" << endl << "                          |        | |" << endl << "                          |        | |" << endl << "                          |        |_|" << endl << "                         o|         _" << endl << "            |\\          /||        (_)" << endl << "            | \\         /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~\033[m|  \\\033[1;34m~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                          |         _" << endl << "                          |        | |" << endl << "                          |        | |" << endl << "                          |        |_|" << endl << "                         o|         _" << endl << "             |\\         /||        (_)" << endl << "             | \\        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~\033[m|  \\\033[1;34m~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                          |         _" << endl << "                          |        | |" << endl << "                          |        | |" << endl << "                          |        |_|" << endl << "                         o|         _" << endl << "              |\\        /||        (_)" << endl << "              | \\       /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~\033[m|  \\\033[1;34m~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                /         |         _" << endl << "               /          |        | |" << endl << "              /____       |        | |" << endl << "                  /       |        |_|" << endl << "                 /       o|         _" << endl << "              |\\/       /||        (_)" << endl << "              | \\       /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~\033[m|  \\\033[1;34m~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      " << last << ">O\033[m\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		getgiant();
	}
	inline void fishing_choose(){
		bool b = (random(1, 100) <= variate::bf);
		int type = gettype();
		if(variate::cnt && variate::cnt < 99){
			bool die = (random(1, 100) <= variate::slip);
			if(die){
				fishing1die(b, type);
			}else{
				fishing1(b, type);
			}
		}else if(variate::cnt >= 99){
			fishing2();
			variate::cnt = 0;
		}else{
			fishing0(b, type);
		}
	}
	inline double fresh(int a){
		if(a >= 8){
			return 1.2;
		}else if(a <= 2){
			return 0.8;
		}else{
			return 1;
		}
	}
	inline void fishing(){
		while(true){
			clear();
			print("1.开始钓鱼, 2.清理鱼池,  3.全部卖出, 4.全部卖出并退出");
			print("当前污染等级: " + to_string(dirty));
			for(int i = 0; i <= 6; i++){
				cout << fish_color[i] << fish_name[i] + "鱼:\033[m" << endl;
				for(int j = 0; j < fish_time[i].size(); j++){
					if(fish_time[i][j] >= 8){
						cout << "\033[1;32m";
					}else if(fish_time[i][j] <= 2){
						cout << "\033[1;31m";
					}else{
						cout << "\033[1m";
					}
					cout << "    新鲜度:" << fish_time[i][j] << " 价格:" << int(fish_money[i][j] * (1 - 0.02 * dirty) * fresh(fish_time[i][j])) << "\033[m" << endl;
				}
				if(fish_time[i].empty()){
					cout << "    暂无" << endl;
				}
			}
			while(true){
				char c = getch();
				if(c == '1'){
					for(int i = 0; i <= 6; i++){
						for(int j = 0; j < fish_time[i].size(); j++){
							fish_time[i][j] -= dirty + 1;
							if(fish_time[i][j] <= 0){
								if(i == 0){
									dirty++;
								}else{
									fish_time[i - 1].push_back(10);
									fish_money[i - 1].push_back(max(fish_money[i][j] - 10, 0));
								}
								for(int k = j + 1; k < fish_time[i].size(); k++){
									fish_time[i][k - 1] = fish_time[i][k];
									fish_money[i][k - 1] = fish_money[i][k];
								}
								fish_time[i].pop_back();
								fish_money[i].pop_back();
								j--;
							}
						}
					}
					fishing_choose();
					break;
				}else if(c == '2'){
					clear();
					if(!dirty){
						cout << "无需清理" << endl;
						break;
					}
					while(true){
						if(variate::cleaning_ball){
							print("1.清理, 2.退出");
							print("当前污染等级: " + to_string(variate::cleaning_ball));
							print("当前清洁剂个数: " + to_string(variate::cleaning_ball));
							char c = 0;
							while(true){
								c = getch();
								if(c == '1' || c == '2'){
									break;
								}
							}
							if(c == '1'){
								variate::cleaning_ball--;
								dirty--;
							}else{
								break;
							}
						}else{
							print("1.购买清洁剂并清理, 2.退出");
							print("当前污染等级: " + to_string(variate::cleaning_ball));
							print("清洁剂: ");
							print("    购买花费: $20, 当前金币数量: $" + to_string(variate::money));
							char c = 0;
							while(true){
								c = getch();
								if(c == '1' || c == '2'){
									break;
								}
							}
							if(c == '1'){
								if(variate::money < 20){
									cout << "金钱不够" << endl;
									break;
								}else{
									variate::money -= 20;
									dirty--;
								}
							}else{
								break;
							}
						}
						if(!dirty){
							cout << "清理完成" << endl;
							break;
						}
					}
					break;
				}else if(c == '3'){
					error("sale");
					for(int i = 0; i <= 6; i++){
						for(int j = 0; j < fish_time[i].size(); j++){
							variate::money += (int)(fish_money[i][j] * (1 - 0.02 * dirty) * fresh(fish_time[i][j]));
						}
						while(!fish_time[i].empty()){
							fish_time[i].pop_back();
						}
						while(!fish_money[i].empty()){
							fish_money[i].pop_back();
						}
					}
					clear();
					cout << "售卖中" << endl;
					break;
				}else if(c == '4'){
					for(int i = 0; i <= 6; i++){
						for(int j = 0; j < fish_time[i].size(); j++){
							variate::money += (int)(fish_money[i][j] * (1 - 0.02 * dirty) * fresh(fish_time[i][j]));
						}
						while(!fish_time[i].empty()){
							fish_time[i].pop_back();
						}
						while(!fish_money[i].empty()){
							fish_money[i].pop_back();
						}
					}
					return;
				}
			}
			sleep(1);
		}
	}
}
#endif
