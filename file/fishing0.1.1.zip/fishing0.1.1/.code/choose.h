#ifndef choose_defined
#define choose_defined
#include<string>
using std::string;
using std::to_string;
#include"variate.h"
inline void choose(){
	print("请选择开局技能");
	print("1.美味诱饵, 2.稀世珍宝, 3.牢靠安全绳, 4.强效清洁剂, 5.大力水手, 6.放长线钓大鱼, 7.孤苦人家");
	print("美味诱饵:");
	print("    上钩速度变为原先的2/3");
	print("稀世珍宝:");
	print("    鱼的价格变为原先的2倍");
	print("牢靠安全绳:");
	print("    脱钩概率由50%变为10%");
	print("强效清洁剂:");
	print("    初始获得1个清洁剂, 并且清洁剂效果翻倍");
	print("大力水手:");
	print("    甩杆倍速由1倍变为2倍");
	print("放长线钓大鱼:");
	print("    大鱼概率由20%变为40%");
	print("孤苦人家:");
	print("    无");
	while(true){
		char c = getch();
		if(c == '1'){
			variate::level = 5;
			break;
		}else if(c == '2'){
			variate::get_level = 5;
			break;
		}else if(c == '3'){
			variate::slip = 10;
			break;
		}else if(c == '4'){
			variate::cleaning_ball = 1;
			variate::cleaning_sub = 2;
			break;
		}else if(c == '5'){
			variate::stime = 2;
			break;
		}else if(c == '6'){
			variate::bf = 40;
			break;
		}else if(c == '7'){
			break;
		}
	}
}
#endif