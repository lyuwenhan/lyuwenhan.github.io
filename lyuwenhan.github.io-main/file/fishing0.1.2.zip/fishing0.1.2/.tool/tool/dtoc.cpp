#include<iostream>
#include<fstream>
using namespace std;
int main(){
	{
		freopen("../paint", "r", stdin);
		string s;
		cout << "	cout";
		while(getline(cin, s)){
			string s2;
			for(char i : s){
				if(i == '\r'){
					break;
				}
				if(i == '\\'){
					s2 += i;
				}
				s2 += i;
			}
			if(!s2.empty()){
				cout << " << \"" << s2 << '"';
			}
			cout << " << endl";
		}
		cout << ';' << endl;
	}
}