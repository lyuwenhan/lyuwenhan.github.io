#ifndef function_defined
#define function_defined
#include<hashtable.h>
#include<iostream>
#include<string>
using std::cout;
using std::hash;
using std::string;
using std::ostream;
using std::to_string;
#include"variate.h"
inline void clear(){
	system("clear");
}
struct endline{}endl;
inline ostream& operator<<(ostream& out, endline e){
	out.flush();
	out << '\r' << std::endl;
	return out;
}
inline char getch(){
	char c = getchar();
	if(c == 3){
		clear();
		cout << "^C" << endl;
		system("stty cooked");
		system("stty echo");
		exit(1);
	}
//	if(c == 26){
//		clear();
//		cout << "^Z" << endl << "[1]+  Stopped                 fishing.run" << endl;
//		system("stty cooked");
//		system("stty echo");
//		exit(1);
//	}
	return c;
}
bool issymbol(char type){
	string symbols = "({[<`~!@#$%^&*-_ +=|;:.?>]})\"'\\/";
	size_t found = symbols.find(type);
	if(found != string::npos){
		return true;
	}else{
		return false;
	}
}
inline string getline(string &ans, bool b = false){
	ans = "";
	char a = 0;
	while((a = getch()) != '\r'){
		if(issymbol(a) || isdigit(a) || islower(a) || isupper(a)){
			ans += a;
			if(b){
				cout << a;
				cout.flush();
			}
		}
		if(a == 127 && ans.length()){
			ans.pop_back();
			if(b){
				cout << "\b \b";
				cout.flush();
			}
		}
	}
	cout << endl;
	return ans;
}
inline unsigned long long to_hash(string s){
	return static_cast<unsigned long long>(hash<string>{}(s));
}
inline void sleep(double time){
	system(((string)"sleep " + to_string(time)).c_str());
}
inline void print(string s, double time = 0.02){
	if(variate::spead == 1000){
		cout << s << endl;
	}else{
		for(char i : s){
			sleep(time / variate::spead);
			cout << i;
			cout.flush();
		}
		cout << endl;
	}
}
inline void printa(string s, double time = 0.02){
	print(s + "    (按enter继续)", time);
	while(getch() != '\r');
}
inline int random(int l, int r){
	int len = r - l + 1;
	int re = rand() * 1.0 / RAND_MAX * len + l;
	return re;
}
#endif