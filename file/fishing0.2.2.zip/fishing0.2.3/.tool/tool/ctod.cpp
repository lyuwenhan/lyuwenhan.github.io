#include<iostream>
#include<fstream>
using namespace std;
int main(){
	{
		ifstream in("../code");
		ofstream out("run.cpp");
		string s;
		out << "#include<iostream>" << endl << "using std::ostream;using std::cout;" << endl << "struct endline{}endl;" << endl << "inline ostream& operator<<(ostream& out, endline){" << endl << "	out.flush();" << endl << "	out << '\\r' << std::endl;" << endl << "	return out;" << endl << "}" << endl << "int main(){" << endl;
		getline(in, s);
		if(s == ""){
			return 114;
		}
		out << s << endl;
		out << '}' << endl;
		in.close();
	}
	system("g++ run.cpp -o >/dev/null run 2>&1 && ./run > ../paint");
}