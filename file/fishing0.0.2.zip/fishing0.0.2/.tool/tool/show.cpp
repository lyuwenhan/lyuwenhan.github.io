#include<iostream>
using namespace std;
int main(){
    freopen("../ans", "r", stdin);
    system("clear");
    string s;
    while(getline(cin, s)){
        cout << s << endl;
    }
}