#include<iostream>
using namespace std;
int main(){
    freopen("../paint", "r", stdin);
    system("clear");
    string s;
    while(getline(cin, s)){
        cout << s << endl;
    }
}