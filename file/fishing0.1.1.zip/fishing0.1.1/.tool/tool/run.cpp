#include<iostream>
using std::ostream;using std::cout;
struct endline{}endl;
inline ostream& operator<<(ostream& out, endline){
	out.flush();
	out << '\r' << std::endl;
	return out;
}
int main(){
	cout << "" << endl << "" << endl << "" << endl << "             /     \\" << endl << "            /       \\" << endl << "           /         \\" << endl << "          /           \\" << endl << "_________/             \\" << endl;
}
