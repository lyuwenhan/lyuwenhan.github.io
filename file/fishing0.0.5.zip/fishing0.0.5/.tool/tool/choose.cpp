#include<iostream>
using namespace std;
int main(){
    system("stty -echo");
    system("stty raw");
    while(true){
        system("clear");
        cout << "1.paint->code, 2.code->paint, 3.exit\r" << endl;
        char c = getchar();
        if(c == '1'){
            system("./r1.sh");
        }else if(c == '2'){
            system("./r2.sh");
        }else if(c == '3'){
            break;
        }
    }
    system("stty echo");
    system("stty cooked");
}