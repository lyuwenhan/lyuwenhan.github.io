#include<iostream>
using namespace std;
struct endline{}eline;
inline ostream& operator<<(ostream& out, endline){
	out.flush();
	out << '\r' << std::endl;
	return out;
}
int main(){
	cout << "  ______     ____      ____     _____" << eline << " |  ____|   / __ \\    / __ \\   |  __ \\" << eline << " | | ___   | |  | |  | |  | |  | |  | |" << eline << " | ||_  |  | |  | |  | |  | |  | |  | |" << eline << " | |__| |  | |__| |  | |__| |  | |__| | " << eline << " |______|   \\____/    \\____/   |_____/ " << eline << "                                        " << eline << "                                        " << eline;
}
