#include<iostream>
#include<fstream>
using namespace std;
int main(){
	{
		freopen("../paint", "r", stdin);
		string s;
		cout << "	cout";
		while(getline(cin, s)){
			cout << " << \"";
			for(char i : s){
				if(i == '\r'){
					break;
				}
				if(i == '\\'){
					cout << i;
				}
				cout << i;
			}
			cout << "\" << eline";
		}
		cout << ';' << endl;
	}
}