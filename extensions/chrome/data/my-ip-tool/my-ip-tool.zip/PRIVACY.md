This extension does not collect, store, or transmit any personal data.
IP lookups are performed directly between the user’s browser and a developer-controlled endpoint (https://my-ip.lyuwenhan.workers.dev) hosted on Cloudflare Workers.
No IP addresses or request data are logged or stored.
