echo -e -n "\e[032;1muser@SDSZ\e[0m:\e[01;34m~/fishing_remade\e[0m$ " && read a
$a 1> /dev/null