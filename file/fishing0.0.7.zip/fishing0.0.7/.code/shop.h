#ifndef shop_defined
#define shop_defined
#include<hashtable.h>
#include<iostream>
#include<string>
using std::cout;
using std::hash;
using std::string;
using std::ostream;
using std::to_string;
#include"variate.h"
#include"function.h"
namespace shop{
	inline void check_fishing(){
		if(!variate::auto_fishing){
			return;
		}
		int now = time(0);
		variate::left += now - variate::ltime;
		variate::ltime = now;
		variate::money += variate::left / (variate::mintime[variate::level] + 20) * variate::maxget[variate::get_level];
		variate::cnt += variate::left / (variate::mintime[variate::level] + 20);
		variate::left %= (variate::mintime[variate::level] + 20);
	}
	inline void shop0(){
		clear();
		print("1.升级上钩速度, 2.升级钓鱼收益, 3.脱钩概率, 4.购买清洁剂, 5.返回。");
		print("上钩速度: ");
		if(variate::level == variate::max_level){
			print("    等级已满。");
		}else{
			print("    当前平均时间: " + to_string((variate::mintime[variate::level] + variate::maxtime[variate::level]) >> 1) + (((variate::mintime[variate::level] + variate::maxtime[variate::level]) & 1) ? ".5" : "") + ", 升级后平均时间: " + to_string((variate::mintime[variate::level + 1] + variate::maxtime[variate::level + 1]) >> 1) + (((variate::mintime[variate::level + 1] + variate::maxtime[variate::level + 1]) & 1) ? ".5" : ""));
			print("    升级花费: $" + to_string(variate::cost[variate::level + 1]) + ", 当前金币数量: $" + to_string(variate::money));
		}
		print("钓鱼收益: ");
		if(variate::get_level == variate::max_level2){
			print("    等级已满。");
		}else{
			print("    当前平均收益: " + to_string((variate::minget[variate::get_level] + variate::maxget[variate::get_level]) >> 1) + (((variate::minget[variate::get_level] + variate::maxget[variate::get_level]) & 1) ? ".5" : "") + ", 升级后平均收益: " + to_string((variate::minget[variate::get_level + 1] + variate::maxget[variate::get_level + 1]) >> 1) + (((variate::minget[variate::get_level + 1] + variate::maxget[variate::get_level + 1]) & 1) ? ".5" : ""));
			print("    升级花费: $" + to_string(variate::cost2[variate::get_level + 1]) + ", 当前金币数量: $" + to_string(variate::money));
		}
		print("脱钩概率: ");
		if(variate::slip == 0){
			print("    等级已满。");
		}else{
			if(variate::slip > 10){
				variate::slip /= 10;
				variate::slip *= 10;
				print("    当前脱钩概率: " + to_string(variate::slip) + "%, 升级后脱钩概率: " + to_string(variate::slip - 10) + "%");
				print("    升级花费: $100, 当前金币数量: $" + to_string(variate::money));
			}else if(variate::slip > 5){
				variate::slip = 10;
				print("    当前脱钩概率: 10%, 升级后脱钩概率: 5%");
				print("    升级花费: $100, 当前金币数量: $" + to_string(variate::money));
			}else if(variate::slip > 1){
				print("    当前脱钩概率: " + to_string(variate::slip) + "%, 升级后脱钩概率: " + to_string(variate::slip - 1) + "%");
				print("    升级花费: $100, 当前金币数量: $" + to_string(variate::money));
			}else{
				print("    当前脱钩概率: 1%, 升级后脱钩概率: 0%");
				print("    升级花费: $500, 当前金币数量: $" + to_string(variate::money));
			}
		}
		print("清洁剂: ");
		print("    当前清洁剂个数: " + to_string(variate::cleaning_ball));
		print("    购买花费: $10, 当前金币数量: $" + to_string(variate::money));
		char type = 0;
		while(true){
			type = getch();
			if(type == '1'){
				if(variate::level == variate::max_level){
					print("等级已满");
					break;
				}else if(variate::money < variate::cost[variate::level + 1]){
					print("金钱不够");
					break;
				}else{
					variate::money -= variate::cost[++variate::level];
					print("购买成功");
					break;
				}
			}else if(type == '2'){
				if(variate::get_level == variate::max_level2){
					print("等级已满");
					break;
				}else if(variate::money < variate::cost2[variate::get_level + 1]){
					print("金钱不够");
					break;
				}else{
					variate::money -= variate::cost2[++variate::get_level];
					print("购买成功");
					break;
				}
			}else if(type == '3'){
				if(variate::slip == 0){
					print("等级已满");
					break;
				}else if(variate::slip == 1){
					if(variate::money < 500){
						print("金钱不够");
						break;
					}else{
						variate::money -= 500;
						variate::slip = 0;
						print("购买成功");
						break;
					}
				}else{
					if(variate::money < 100){
						print("金钱不够");
						break;
					}else{
						variate::money -= 100;
						if(variate::slip > 10){
							variate::slip -= 10;
						}else if(variate::slip > 5){
							variate::slip = 5;
						}else if(variate::slip > 0){
							variate::slip -= 1;
						}
						print("购买成功");
						break;
					}
				}
			}else if(type == '4'){
				if(variate::slip == 0){
					print("等级已满");
					break;
				}else if(variate::slip == 1){
					if(variate::money < 500){
						print("金钱不够");
						break;
					}else{
						variate::money -= 500;
						variate::slip = 0;
						print("购买成功");
						break;
					}
				}else{
					if(variate::money < 10){
						print("金钱不够");
						break;
					}else{
						variate::money -= 10;
						variate::cleaning_ball++;
						print("购买成功");
						break;
					}
				}
			}else if(type == '5'){
				break;
			}
		}
	}
	inline void shop1(){
		clear();
		printa("这里是超级商店, 可以买一些特殊的商品。");
		clear();
		print("1.游戏倍速, 2.升级大鱼概率 3.购买自动钓鱼机, 4.返回。");
		print("游戏倍速: ");
		if(variate::stime == 10){
			print("    等级已满。");
		}else{
			print("    当前倍速: " + to_string(variate::stime) + ", 升级后游戏倍速: " + to_string(variate::stime + 1));
			print("    升级花费: $1000, 当前金币数量: $" + to_string(variate::money));
		}
		print("大鱼概率: ");
		if(variate::bf >= 60){
			print("    等级已满。");
		}else{
			print("    当前大鱼概率: " + to_string(variate::bf) + ", 升级后大鱼概率" + to_string(variate::bf + 5));
			print("    升级花费: $1000, 当前金币数量: $" + to_string(variate::money));
		}
		print("自动钓鱼机: ");
		if(variate::auto_fishing){
			print("    已有");
		}else{
			print("    升级花费: $2000, 当前金币数量: $" + to_string(variate::money));
		}
		char type;
		while(true){
			type = getch();
			if(type == '1'){
				if(variate::stime >= 10){
					print("等级已满。");
					break;
				}else if(variate::money < 1000){
					print("金钱不够");
					break;
				}else{
					variate::money -= 1000;
					variate::stime++;
					print("购买成功");
					break;
				}
			}else if(type == '2'){
				if(variate::bf >= 60){
					print("等级已满。");
					break;
				}else if(variate::money < 1000){
					print("金钱不够");
					break;
				}else{
					variate::money -= 1000;
					variate::bf += 5;
					print("购买成功");
					break;
				}
			}else if(type == '3'){
				if(variate::auto_fishing){
					print("等级已满。");
					break;
				}else if(variate::money < 2000){
					print("金钱不够");
					break;
				}else{
					variate::money -= 2000;
					variate::auto_fishing = true;
					variate::ltime = time(0);
					print("购买成功");
					break;
				}
				break;
			}else if(type == '4'){
				break;
			}
		}
	}
	inline void shop(){
		clear();
		if(variate::level != variate::max_level || variate::get_level != variate::max_level2){
			print("1.普通商店, 2.超级商店, 3.退出。");
			char type;
			while(true){
				type = getch();
				if(type == '1'){
					shop0();
					break;
				}else if(type == '2'){
					shop1();
					break;
				}else if(type == '3'){
					break;
				}
			}
		}else{
			shop1();
		}
	}
}
#endif