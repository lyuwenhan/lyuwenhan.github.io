#ifndef story_defined
#define story_defined
#include"variate.h"
#include"function.h"
inline void story(){
	clear();
	printa("2136年, 全球冰山融化了");
	printa("海平面上升了许多");
	printa("大部分城市被海平面淹没了");
	printa("你待在一个小岛上, 等待救援");
	printa("你每天只能钓鱼度日");
	clear();
}
#endif